import { ArrowRight } from 'lucide-react'

export type HeadlineVariant = 'deep-work' | 'attribution'

type SignInHeroProps = {
  variant: HeadlineVariant
  hidden: boolean
  onToggleVariant: () => void
  onOpenSignIn: () => void
}

export function SignInHero({ variant, hidden, onToggleVariant, onOpenSignIn }: SignInHeroProps) {
  const phrase = variant === 'deep-work' ? 'Deep Work' : 'Attribution'

  return (
    <section
      aria-hidden={hidden}
      className={`-mt-6 flex flex-1 flex-col items-center justify-center px-6 text-center transition-all duration-500 ${
        hidden ? 'pointer-events-none scale-[0.98] opacity-0' : 'opacity-100'
      }`}
    >
      <h1 className="text-balance text-4xl font-semibold leading-[1.12] tracking-[-0.03em] text-white drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)] sm:text-5xl md:text-[56px]">
        Redefining{' '}
        <button
          type="button"
          onClick={onToggleVariant}
          tabIndex={hidden ? -1 : 0}
          title="Toggle headline"
          className="pointer-events-auto cursor-pointer rounded-md outline-offset-4"
        >
          {phrase}
        </button>
        <br />
        with AI-Powered Data Precision.
      </h1>

      <p className="mt-4 text-[15px] font-normal tracking-[-0.01em] text-zinc-300/90">
        The bridge between attribution and intelligence.
      </p>

      <div className="mt-8 flex items-center gap-3.5">
        <button
          type="button"
          onClick={onOpenSignIn}
          tabIndex={hidden ? -1 : 0}
          className="pointer-events-auto rounded-full bg-white px-6 py-2.5 text-[13.5px] font-medium text-[#09090B] shadow-[0_0_30px_rgba(255,255,255,0.25)] transition-all hover:scale-[1.02] hover:bg-zinc-200 active:scale-[0.98]"
        >
          {variant === 'deep-work' ? 'Enter Campfire' : 'Book a Demo'}
        </button>
        <button
          type="button"
          onClick={onOpenSignIn}
          tabIndex={hidden ? -1 : 0}
          className="pointer-events-auto flex items-center gap-2 rounded-full border border-white/25 bg-black/50 px-6 py-2.5 text-[13.5px] font-normal text-white backdrop-blur-md transition-all hover:border-white/50 hover:bg-white/[0.08]"
        >
          Explore Roadmap
          <ArrowRight aria-hidden="true" className="size-3.5" />
        </button>
      </div>
    </section>
  )
}
