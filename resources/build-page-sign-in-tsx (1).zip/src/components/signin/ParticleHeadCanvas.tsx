'use client'

import { useEffect, useRef } from 'react'
import { createParticles, TINT_CYAN, TINT_DEEP, TINT_ICE } from './particle-head-geometry'

const WARP_DURATION = 1.2
const REPULSION_RADIUS = 120
const SPRING = 0.06
const DAMPING = 0.85
const CAMERA_DISTANCE = 4.2
const HEAT_LEVELS = 8

type RGB = [number, number, number]

const TINTS: Record<number, RGB> = {
  [TINT_ICE]: [205, 232, 255],
  [TINT_CYAN]: [125, 211, 252],
  [TINT_DEEP]: [96, 165, 250],
}
const HOT_COLORS: RGB[] = [
  [56, 189, 248],
  [163, 230, 53],
]

function buildPalette() {
  const palette: string[][][] = []
  for (const tint of [TINT_ICE, TINT_CYAN, TINT_DEEP]) {
    palette[tint] = HOT_COLORS.map((hot) => {
      const levels: string[] = []
      for (let h = 0; h < HEAT_LEVELS; h++) {
        const t = h / (HEAT_LEVELS - 1)
        const base = TINTS[tint]
        const r = Math.round(base[0] + (hot[0] - base[0]) * t)
        const g = Math.round(base[1] + (hot[1] - base[1]) * t)
        const b = Math.round(base[2] + (hot[2] - base[2]) * t)
        levels.push(`rgb(${r},${g},${b})`)
      }
      return levels
    })
  }
  return palette
}

const springEase = (t: number) => 1 - Math.exp(-6 * t) * Math.cos(t * Math.PI * 1.25)

export function ParticleHeadCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d', { alpha: false })
    if (!canvas || !ctx) return

    const particles = createParticles()
    const palette = buildPalette()
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    let width = 0
    let height = 0
    let dpr = 1
    let unit = 1
    let centerX = 0
    let centerY = 0

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2)
      width = window.innerWidth
      height = window.innerHeight
      canvas.width = Math.floor(width * dpr)
      canvas.height = Math.floor(height * dpr)
      unit = Math.min(height * 0.36, width * 0.55)
      centerX = width / 2
      centerY = height * 0.46
    }
    resize()

    const mouse = { x: -9999, y: -9999, prevX: -9999, prevY: -9999, vx: 0, vy: 0, active: false }
    const onPointerMove = (event: PointerEvent) => {
      if (!mouse.active) {
        mouse.prevX = event.clientX
        mouse.prevY = event.clientY
      }
      mouse.x = event.clientX
      mouse.y = event.clientY
      mouse.active = true
    }
    const onPointerLeave = () => {
      mouse.active = false
    }

    window.addEventListener('resize', resize)
    window.addEventListener('pointermove', onPointerMove, { passive: true })
    document.documentElement.addEventListener('pointerleave', onPointerLeave)
    window.addEventListener('blur', onPointerLeave)

    const startTime = performance.now() - (reduceMotion ? WARP_DURATION * 1000 : 0)
    let warpSettled = reduceMotion
    let frame = 0

    const render = (now: number) => {
      frame = requestAnimationFrame(render)
      const elapsed = (now - startTime) / 1000
      const warping = elapsed < WARP_DURATION

      if (!warping && !warpSettled) {
        warpSettled = true
        for (const p of particles) {
          p.x = p.originX
          p.y = p.originY
          p.z = p.originZ
          p.vx = p.vy = p.vz = 0
        }
      }

      const rawVX = mouse.active ? mouse.x - mouse.prevX : 0
      const rawVY = mouse.active ? mouse.y - mouse.prevY : 0
      mouse.prevX = mouse.x
      mouse.prevY = mouse.y
      mouse.vx = Math.max(-40, Math.min(40, mouse.vx * 0.6 + rawVX * 0.4))
      mouse.vy = Math.max(-40, Math.min(40, mouse.vy * 0.6 + rawVY * 0.4))

      const rotation = Math.sin(now * 0.001) * (reduceMotion ? 0.04 : 0.12)
      const cosR = Math.cos(rotation)
      const sinR = Math.sin(rotation)

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.globalCompositeOperation = 'source-over'
      ctx.globalAlpha = 1
      ctx.fillStyle = '#000'
      ctx.fillRect(0, 0, width, height)
      ctx.globalCompositeOperation = 'lighter'

      const radiusSq = REPULSION_RADIUS * REPULSION_RADIUS

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i]

        if (warping) {
          const local = Math.min(1, Math.max(0, (elapsed - p.delay) / (WARP_DURATION - p.delay)))
          const e = springEase(local)
          p.x = p.startX + (p.originX - p.startX) * e
          p.y = p.startY + (p.originY - p.startY) * e
          p.z = p.startZ + (p.originZ - p.startZ) * e
        }

        const xr = p.x * cosR + p.z * sinR
        const zr = -p.x * sinR + p.z * cosR
        const depthGap = CAMERA_DISTANCE - zr
        if (depthGap < 0.25) {
          p.prevSX = Number.NaN
          continue
        }
        const persp = CAMERA_DISTANCE / depthGap
        const sx = centerX + xr * unit * persp
        const sy = centerY + p.y * unit * persp

        if (!warping) {
          if (mouse.active) {
            const dx = sx - mouse.x
            const dy = sy - mouse.y
            const distSq = dx * dx + dy * dy
            if (distSq < radiusSq && distSq > 0.01) {
              const dist = Math.sqrt(distSq)
              const falloff = 1 - dist / REPULSION_RADIUS
              const strength = falloff * falloff
              const toWorld = 1 / (unit * persp)
              const pushX = ((dx / dist) * 3.6 + mouse.vx * 0.3) * strength
              const pushY = ((dy / dist) * 3.6 + mouse.vy * 0.3) * strength
              p.vx += pushX * toWorld
              p.vy += pushY * toWorld
              p.vz += strength * 0.012
              if (falloff > p.heat) p.heat = falloff
            }
          }

          p.vx = (p.vx + (p.originX - p.x) * SPRING) * DAMPING
          p.vy = (p.vy + (p.originY - p.y) * SPRING) * DAMPING
          p.vz = (p.vz + (p.originZ - p.z) * SPRING) * DAMPING
          p.x += p.vx
          p.y += p.vy
          p.z += p.vz
          p.heat *= 0.95
        }

        const nzr = -p.nx * sinR + p.nz * cosR
        const rim = Math.pow(1 - Math.min(1, Math.abs(nzr)), 1.4)
        const facing = nzr < -0.2 ? 0.45 : 1
        const depthFade = Math.min(1, Math.max(0.3, (zr + 1.1) / 1.8))
        const light = p.isDust ? 1 : (0.5 + 0.7 * Math.max(rim, p.glow)) * facing
        const alpha = Math.min(1, p.baseAlpha * light * depthFade + p.heat * 0.6)
        const heatLevel = Math.min(HEAT_LEVELS - 1, Math.round(p.heat * (HEAT_LEVELS - 1) * 1.4))
        const color = palette[p.color][p.hot][heatLevel]
        const size = p.size * 1.35 * persp * (1 + p.heat * 0.6)

        if (warping) {
          if (!Number.isNaN(p.prevSX)) {
            ctx.globalAlpha = alpha
            ctx.strokeStyle = color
            ctx.lineWidth = size
            ctx.beginPath()
            ctx.moveTo(p.prevSX, p.prevSY)
            ctx.lineTo(sx, sy)
            ctx.stroke()
          }
          p.prevSX = sx
          p.prevSY = sy
          continue
        }

        ctx.globalAlpha = alpha
        ctx.fillStyle = color
        ctx.fillRect(sx - size / 2, sy - size / 2, size, size)

        if (!p.isDust && (rim > 0.6 || p.glow > 0.6 || p.heat > 0.3)) {
          const halo = size * 3.2
          ctx.globalAlpha = alpha * 0.1
          ctx.fillRect(sx - halo / 2, sy - halo / 2, halo, halo)
        }
      }
    }

    frame = requestAnimationFrame(render)

    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener('resize', resize)
      window.removeEventListener('pointermove', onPointerMove)
      document.documentElement.removeEventListener('pointerleave', onPointerLeave)
      window.removeEventListener('blur', onPointerLeave)
    }
  }, [])

  return <canvas ref={canvasRef} aria-hidden="true" className="fixed inset-0 z-0 h-full w-full bg-black" />
}
