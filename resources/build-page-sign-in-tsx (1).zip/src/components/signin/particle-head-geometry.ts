export const PARTICLE_COUNT = 4500
const CORE_COUNT = Math.round(PARTICLE_COUNT * 0.75)
const DUST_COUNT = PARTICLE_COUNT - CORE_COUNT

export const TINT_ICE = 0
export const TINT_CYAN = 1
export const TINT_DEEP = 2

export type Particle = {
  x: number
  y: number
  z: number
  originX: number
  originY: number
  originZ: number
  vx: number
  vy: number
  vz: number
  size: number
  /** Palette tint index (TINT_ICE | TINT_CYAN | TINT_DEEP). */
  color: number
  startX: number
  startY: number
  startZ: number
  delay: number
  /** Surface normal on the XZ plane, used for rim lighting. */
  nx: number
  nz: number
  /** 0..1 brightness boost for facial features (brow, nose, chin). */
  glow: number
  baseAlpha: number
  heat: number
  /** 0 = electric cyan on hover, 1 = neon lime on hover. */
  hot: number
  isDust: boolean
  prevSX: number
  prevSY: number
}

function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const gauss = (v: number, mu: number, sigma: number) =>
  Math.exp(-((v - mu) * (v - mu)) / (2 * sigma * sigma))

const clamp01 = (v: number) => Math.min(1, Math.max(0, v))

const smoothstep = (a: number, b: number, v: number) => {
  const t = clamp01((v - a) / (b - a))
  return t * t * (3 - 2 * t)
}

/** Head cross-section radii at height y (head-local units, +y is down). */
function headRadii(y: number) {
  const yc = -0.25
  const ry = 0.75
  const k = (y - yc) / ry
  const s = Math.sqrt(Math.max(0, 1 - k * k))
  let rx = 0.6 * s
  const rzFront = 0.64 * s
  let rzBack = 0.76 * s
  if (y > -0.05) {
    const t = (y + 0.05) / 0.55
    rx *= 1 - 0.28 * t * t
    rzBack *= 1 - 0.35 * t
  }
  rx *= 1 - 0.05 * gauss(y, -0.42, 0.08)
  return { rx, rzFront, rzBack }
}

/** Facial relief added along +z (toward camera) on the front of the head. */
function faceRelief(x: number, y: number) {
  const noseRamp = smoothstep(-0.24, 0.12, y) * (1 - smoothstep(0.12, 0.2, y))
  const nose = 0.2 * noseRamp * gauss(x, 0, 0.05 + 0.04 * noseRamp)
  const brow = 0.06 * gauss(y, -0.3, 0.04) * gauss(x, 0, 0.28)
  const eyes = -0.09 * gauss(y, -0.19, 0.055) * (gauss(x, 0.2, 0.08) + gauss(x, -0.2, 0.08))
  const cheeks = 0.04 * gauss(y, -0.05, 0.06) * (gauss(x, 0.31, 0.08) + gauss(x, -0.31, 0.08))
  const lips = 0.05 * gauss(y, 0.27, 0.03) * gauss(x, 0, 0.1)
  const mouth = -0.025 * gauss(y, 0.31, 0.012) * gauss(x, 0, 0.1)
  const chin = 0.06 * gauss(y, 0.42, 0.045) * gauss(x, 0, 0.13)
  return nose + brow + eyes + cheeks + lips + mouth + chin
}

function headSurface(y: number, phi: number) {
  const { rx, rzFront, rzBack } = headRadii(y)
  const sinP = Math.sin(phi)
  const cosP = Math.cos(phi)
  const x = rx * sinP
  let z = cosP >= 0 ? rzFront * cosP : rzBack * cosP
  const frontWeight = Math.pow(Math.max(0, cosP), 3)
  const relief = faceRelief(x, y) * frontWeight
  z += relief
  return { x, z, nx: sinP, nz: cosP, relief }
}

export function createParticles(seed = 7): Particle[] {
  const rand = mulberry32(seed)
  const normal = () => {
    const u = Math.max(1e-6, rand())
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rand())
  }
  const silhouettePhi = (spread: number) =>
    (rand() < 0.5 ? -1 : 1) * (Math.PI / 2) + normal() * spread
  const particles: Particle[] = []

  const push = (
    x: number,
    y: number,
    z: number,
    opts: { nx: number; nz: number; glow: number; size: number; tint: number; alpha: number; dust?: boolean },
  ) => {
    const cx = x
    const cy = y + 0.25
    const len = Math.hypot(cx, cy) || 1
    const dirX = cx / len + normal() * 0.35
    const dirY = cy / len + normal() * 0.35
    const reach = 2 + rand() * 3
    particles.push({
      x,
      y,
      z,
      originX: x,
      originY: y,
      originZ: z,
      vx: 0,
      vy: 0,
      vz: 0,
      size: opts.size,
      color: opts.tint,
      startX: x + dirX * reach,
      startY: y + dirY * reach,
      startZ: 2.4 + rand() * 1.3,
      delay: rand() * 0.25,
      nx: opts.nx,
      nz: opts.nz,
      glow: opts.glow,
      baseAlpha: opts.alpha,
      heat: 0,
      hot: rand() < 0.3 ? 1 : 0,
      isDust: opts.dust ?? false,
      prevSX: Number.NaN,
      prevSY: Number.NaN,
    })
  }

  const headCount = Math.round(CORE_COUNT * 0.6)
  const featureCount = Math.round(CORE_COUNT * 0.13)
  const earCount = Math.round(CORE_COUNT * 0.03)
  const neckCount = Math.round(CORE_COUNT * 0.08)
  const shoulderCount = CORE_COUNT - headCount - featureCount - earCount - neckCount

  for (let i = 0; i < headCount; i++) {
    const y = -0.25 + 0.75 * (2 * rand() - 1)
    const phi = rand() < 0.38 ? silhouettePhi(0.22) : rand() * Math.PI * 2
    const p = headSurface(y, phi)
    push(p.x, y, p.z, {
      nx: p.nx,
      nz: p.nz,
      glow: clamp01(p.relief * 9),
      size: 0.7 + rand() * 0.9,
      tint: rand() < 0.55 ? TINT_ICE : TINT_CYAN,
      alpha: 0.65 + rand() * 0.35,
    })
  }

  const featureCurves: Array<(t: number) => { y: number; phi: number }> = [
    (t) => ({ y: -0.3 + t * 0.45, phi: normal() * 0.015 }),
    (t) => {
      const s = t * 2 - 1
      const u = 0.1 + Math.abs(s) * 0.65
      return { y: -0.29 - 0.035 * Math.sin((Math.PI * (u - 0.1)) / 0.65), phi: Math.sign(s) * u }
    },
    (t) => {
      const s = t * 2 - 1
      return { y: 0.05 + 0.4 * (1 - Math.pow(Math.abs(s), 1.5)), phi: s * 1.45 }
    },
    (t) => ({ y: 0.29 + normal() * 0.006, phi: (t * 2 - 1) * 0.32 }),
    (t) => {
      const a = t * Math.PI * 2
      const ex = 0.2 * (t < 0.5 ? 1 : -1) + Math.cos(a * 2) * 0.075
      const ey = -0.19 + Math.sin(a * 2) * 0.03
      return { y: ey, phi: Math.asin(Math.max(-1, Math.min(1, ex / headRadii(ey).rx))) }
    },
  ]
  const curveWeights = [0.26, 0.2, 0.38, 0.1, 0.06]
  for (let c = 0; c < featureCurves.length; c++) {
    const count = Math.round(featureCount * curveWeights[c])
    for (let i = 0; i < count; i++) {
      const { y, phi } = featureCurves[c](rand())
      const p = headSurface(y, phi)
      push(p.x + normal() * 0.006, y + normal() * 0.006, p.z + 0.01, {
        nx: p.nx,
        nz: p.nz,
        glow: 0.85 + rand() * 0.15,
        size: 1 + rand() * 0.8,
        tint: TINT_CYAN,
        alpha: 0.75 + rand() * 0.25,
      })
    }
  }

  for (let i = 0; i < earCount; i++) {
    const side = rand() < 0.5 ? -1 : 1
    const a = rand() * Math.PI * 2
    const ring = 0.7 + rand() * 0.3
    const y = -0.12 + Math.sin(a) * 0.14 * ring
    const { rx } = headRadii(-0.12)
    push(side * (rx + 0.03 + Math.cos(a) * 0.025), y, -0.05 + Math.cos(a) * 0.07 * ring, {
      nx: side,
      nz: 0,
      glow: 0.4,
      size: 0.8 + rand() * 0.7,
      tint: TINT_CYAN,
      alpha: 0.6 + rand() * 0.3,
    })
  }

  for (let i = 0; i < neckCount; i++) {
    const y = 0.3 + rand() * 0.7
    const r = 0.25 + 0.06 * smoothstep(0.75, 1, y)
    const phi = rand() < 0.5 ? silhouettePhi(0.18) : rand() * Math.PI * 2
    push(r * Math.sin(phi), y, r * Math.cos(phi) - 0.08, {
      nx: Math.sin(phi),
      nz: Math.cos(phi),
      glow: 0,
      size: 0.7 + rand() * 0.8,
      tint: rand() < 0.5 ? TINT_ICE : TINT_CYAN,
      alpha: 0.45 + rand() * 0.4,
    })
  }

  for (let i = 0; i < shoulderCount; i++) {
    const y = 0.85 + 0.9 * Math.pow(rand(), 1.3)
    const spread = clamp01((y - 0.85) / 0.55)
    const halfWidth = 0.27 + 1.3 * Math.sqrt(spread)
    const depth = 0.3 + 0.22 * spread
    const phi = rand() < 0.3 ? silhouettePhi(0.2) : (rand() * 2 - 1) * Math.PI * 0.75
    push(halfWidth * Math.sin(phi), y, depth * Math.cos(phi) - 0.1, {
      nx: Math.sin(phi),
      nz: Math.cos(phi),
      glow: 0,
      size: 0.7 + rand() * 0.9,
      tint: rand() < 0.5 ? TINT_ICE : TINT_CYAN,
      alpha: 0.4 + rand() * 0.45,
    })
  }

  for (let i = 0; i < DUST_COUNT; i++) {
    const side = rand() < 0.5 ? -1 : 1
    const scattered = rand() < 0.15
    const x = scattered ? (rand() * 2 - 1) * 2.8 : side * (0.75 + Math.abs(normal()) * 0.85)
    const y = -1.25 + rand() * 2.8
    const z = normal() * 0.8
    push(x, y, z, {
      nx: 0,
      nz: 1,
      glow: 0,
      size: 0.5 + rand() * 1.1,
      tint: rand() < 0.65 ? TINT_DEEP : TINT_ICE,
      alpha: 0.18 + rand() * 0.45,
      dust: true,
    })
  }

  return particles
}
