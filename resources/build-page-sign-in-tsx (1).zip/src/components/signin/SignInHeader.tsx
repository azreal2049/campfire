const NAV_LINKS = ['Home', 'Features', 'Coverage', 'Company', 'Pricing'] as const

type SignInHeaderProps = {
  onGetStarted: () => void
}

export function SignInHeader({ onGetStarted }: SignInHeaderProps) {
  return (
    <header className="mx-auto flex w-full max-w-[1040px] items-center justify-between px-6 pt-8">
      <a
        href="#"
        className="pointer-events-auto flex items-start gap-1 text-[17px] font-semibold tracking-tight text-white"
      >
        Campfire
        <span className="mt-0.5 text-[10px] font-medium leading-none tracking-normal text-zinc-500">AI</span>
      </a>

      <nav aria-label="Primary" className="hidden items-center gap-9 text-[13.5px] font-normal text-zinc-400 md:flex">
        {NAV_LINKS.map((label) => {
          const active = label === 'Home'
          return (
            <a
              key={label}
              href={active ? '#' : `#${label.toLowerCase()}`}
              aria-current={active ? 'page' : undefined}
              className={`pointer-events-auto transition-colors hover:text-white ${active ? 'text-white' : ''}`}
            >
              {label}
            </a>
          )
        })}
      </nav>

      <button
        type="button"
        onClick={onGetStarted}
        className="pointer-events-auto rounded-full bg-white px-5 py-2 text-[13px] font-medium text-black shadow-[0_0_25px_rgba(255,255,255,0.35)] transition-all hover:scale-[1.03] hover:bg-zinc-200 active:scale-[0.98]"
      >
        Get started
      </button>
    </header>
  )
}
