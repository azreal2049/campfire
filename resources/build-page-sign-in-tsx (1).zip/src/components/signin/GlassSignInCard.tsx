'use client'

import { useEffect, useId, useRef, useState, type FormEvent, type KeyboardEvent } from 'react'
import { X } from 'lucide-react'
import { useCampfireStore, type CampfireRole } from '@/src/store/useCampfireStore'

const ROLES: Array<{ value: CampfireRole; label: string; icon: string }> = [
  { value: 'developer', label: 'Developer', icon: '💻' },
  { value: 'student', label: 'Student', icon: '🧬' },
]

const HANDLE_PATTERN = /^[a-z0-9_]{2,20}$/

type GlassSignInCardProps = {
  onClose: () => void
}

const preventImeSubmit = (event: KeyboardEvent<HTMLInputElement>) => {
  if (event.key === 'Enter' && (event.nativeEvent.isComposing || event.keyCode === 229)) event.preventDefault()
}

export function GlassSignInCard({ onClose }: GlassSignInCardProps) {
  const signIn = useCampfireStore((state) => state.signIn)
  const savedName = useCampfireStore((state) => state.displayName)
  const savedHandle = useCampfireStore((state) => state.handle)
  const savedRole = useCampfireStore((state) => state.role)

  const [displayName, setDisplayName] = useState(savedName)
  const [handle, setHandle] = useState(savedHandle)
  const [role, setRole] = useState<CampfireRole>(savedRole ?? 'developer')
  const [error, setError] = useState<string | null>(null)

  const nameRef = useRef<HTMLInputElement>(null)
  const titleId = useId()
  const nameId = useId()
  const handleId = useId()
  const errorId = useId()

  useEffect(() => {
    nameRef.current?.focus()
    const onKey = (event: globalThis.KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const name = displayName.trim()
    const normalizedHandle = handle.trim().replace(/^@+/, '').toLowerCase()
    if (name.length < 2) {
      setError('Display name needs at least 2 characters.')
      return
    }
    if (!HANDLE_PATTERN.test(normalizedHandle)) {
      setError('Handle must be 2–20 letters, numbers, or underscores.')
      return
    }
    setError(null)
    signIn({ displayName: name.slice(0, 40), handle: normalizedHandle, role })
  }

  return (
    <div className="pointer-events-auto fixed inset-0 z-20 flex items-center justify-center px-5">
      <button
        type="button"
        aria-label="Close sign in"
        tabIndex={-1}
        onClick={onClose}
        className="absolute inset-0 cursor-default bg-black/30 duration-300 animate-in fade-in"
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="relative w-full max-w-[400px] rounded-3xl border border-white/[0.12] bg-[#09090D]/80 p-7 shadow-[0_24px_80px_rgba(0,0,0,0.9)] backdrop-blur-2xl duration-300 animate-in fade-in zoom-in-95 slide-in-from-bottom-2"
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-8 top-0 h-px bg-gradient-to-r from-transparent via-sky-300/60 to-transparent"
        />
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute right-5 top-5 rounded-full p-1.5 text-zinc-500 transition-colors hover:bg-white/[0.06] hover:text-white"
        >
          <X className="size-4" aria-hidden="true" />
        </button>

        <h2 id={titleId} className="text-[20px] font-semibold tracking-[-0.02em] text-white">
          Join the Campfire
        </h2>
        <p className="mt-1.5 text-[13.5px] leading-relaxed text-zinc-400">
          Set up your profile to start a deep work session.
        </p>

        <form onSubmit={handleSubmit} noValidate className="mt-6 flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <label htmlFor={nameId} className="text-[12.5px] font-medium text-zinc-300">
              Display Name
            </label>
            <input
              ref={nameRef}
              id={nameId}
              value={displayName}
              onChange={(event) => setDisplayName(event.target.value)}
              onKeyDown={preventImeSubmit}
              autoComplete="name"
              maxLength={40}
              placeholder="Ada Lovelace"
              aria-describedby={error ? errorId : undefined}
              className="h-11 rounded-xl border border-white/10 bg-white/[0.04] px-3.5 text-[14px] text-white placeholder:text-zinc-600 outline-none transition-colors focus:border-sky-400/60 focus:bg-white/[0.06] focus:ring-2 focus:ring-sky-400/20"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor={handleId} className="text-[12.5px] font-medium text-zinc-300">
              @username Handle
            </label>
            <div className="flex h-11 items-center rounded-xl border border-white/10 bg-white/[0.04] px-3.5 transition-colors focus-within:border-sky-400/60 focus-within:bg-white/[0.06] focus-within:ring-2 focus-within:ring-sky-400/20">
              <span aria-hidden="true" className="text-[14px] text-zinc-500">
                @
              </span>
              <input
                id={handleId}
                value={handle}
                onChange={(event) => setHandle(event.target.value.replace(/^@+/, ''))}
                onKeyDown={preventImeSubmit}
                autoComplete="username"
                autoCapitalize="none"
                spellCheck={false}
                maxLength={21}
                placeholder="ada_codes"
                aria-describedby={error ? errorId : undefined}
                className="h-full w-full bg-transparent pl-1 text-[14px] text-white placeholder:text-zinc-600 outline-none"
              />
            </div>
          </div>

          <fieldset className="flex flex-col gap-1.5">
            <legend className="mb-1.5 text-[12.5px] font-medium text-zinc-300">Role</legend>
            <div role="radiogroup" className="grid grid-cols-2 gap-2">
              {ROLES.map((option) => {
                const selected = role === option.value
                return (
                  <button
                    key={option.value}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    onClick={() => setRole(option.value)}
                    className={`flex h-10 items-center justify-center gap-2 rounded-full border text-[13px] font-medium transition-all ${
                      selected
                        ? 'border-sky-400/60 bg-sky-400/10 text-white shadow-[0_0_20px_rgba(56,189,248,0.25)]'
                        : 'border-white/10 bg-white/[0.03] text-zinc-400 hover:border-white/25 hover:text-white'
                    }`}
                  >
                    <span aria-hidden="true">{option.icon}</span>
                    {option.label}
                  </button>
                )
              })}
            </div>
          </fieldset>

          {error ? (
            <p id={errorId} role="alert" className="text-[12.5px] text-rose-400">
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            className="mt-2 h-11 rounded-full bg-white text-[14px] font-medium text-[#09090B] shadow-[0_0_30px_rgba(255,255,255,0.25)] transition-all hover:scale-[1.02] hover:bg-zinc-200 active:scale-[0.98]"
          >
            {'Ignite Session →'}
          </button>
        </form>
      </div>
    </div>
  )
}
