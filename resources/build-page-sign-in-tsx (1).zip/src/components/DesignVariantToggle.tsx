'use client'

import { useCampfireStore } from '@/src/store/useCampfireStore'

export function DesignVariantToggle() {
  const variant = useCampfireStore((state) => state.signInVariant)
  const setVariant = useCampfireStore((state) => state.setSignInVariant)
  const isDraft = variant === 'draft'

  return (
    <div className="fixed bottom-4 left-4 z-[100] flex items-center gap-2 rounded-full border border-white/15 bg-black/70 py-1 pl-3 pr-1 text-[11px] text-zinc-300 backdrop-blur-md">
      <span className="flex items-center gap-1.5">
        <span
          aria-hidden="true"
          className={isDraft ? 'size-1.5 rounded-full bg-[#ffad5c]' : 'size-1.5 rounded-full bg-sky-400'}
        />
        {isDraft ? 'Draft design' : 'Previous design'}
      </span>
      <button
        type="button"
        onClick={() => setVariant(isDraft ? 'classic' : 'draft')}
        className="rounded-full bg-white px-3 py-1 font-medium text-black transition-colors hover:bg-zinc-200"
      >
        {isDraft ? 'Use previous' : 'View draft'}
      </button>
    </div>
  )
}
