'use client'

import { DesignVariantToggle } from '@/src/components/DesignVariantToggle'
import PageLobby from '@/src/pages/PageLobby'
import PageSignIn from '@/src/pages/PageSignIn'
import PageSignInDraft from '@/src/pages/PageSignInDraft'
import { useCampfireStore } from '@/src/store/useCampfireStore'

export function CampfireApp() {
  const activePage = useCampfireStore((state) => state.activePage)
  const signInVariant = useCampfireStore((state) => state.signInVariant)

  if (activePage === 'page-lobby') return <PageLobby />

  return (
    <>
      {signInVariant === 'draft' ? <PageSignInDraft /> : <PageSignIn />}
      <DesignVariantToggle />
    </>
  )
}
