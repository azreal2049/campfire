'use client'

import { Share2 } from 'lucide-react'
import { useState } from 'react'

type DraftFooterBarProps = { onNext: () => void; isLast: boolean }

export function DraftFooterBar({ onNext, isLast }: DraftFooterBarProps) {
  const [copied, setCopied] = useState(false)

  const share = async () => {
    const url = window.location.href
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Campfire', url })
      } else {
        await navigator.clipboard.writeText(url)
        setCopied(true)
        setTimeout(() => setCopied(false), 1800)
      }
    } catch {
      // user dismissed the share sheet
    }
  }

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-30 flex items-center justify-center px-5 pb-4 sm:px-8">
      <button
        type="button"
        onClick={onNext}
        aria-label={isLast ? 'Back to top' : 'Next section'}
        className={`pointer-events-auto flex h-6 w-4 justify-center rounded-full border border-[#1a1a1a]/70 pt-1 transition-transform ${isLast ? 'rotate-180' : ''}`}
      >
        <span className="draft-motion block h-1.5 w-px animate-[draft-scroll-dot_1.6s_ease-in-out_infinite] bg-[#1a1a1a]" />
      </button>
      <button
        type="button"
        onClick={share}
        className="pointer-events-auto absolute right-5 flex items-center gap-1.5 text-[10px] uppercase tracking-[0.06em] text-[#1a1a1a] transition-opacity hover:opacity-60 sm:right-8"
      >
        <Share2 className="size-3" aria-hidden="true" />
        <span aria-live="polite">{copied ? 'Copied' : 'Share'}</span>
      </button>
    </div>
  )
}
