import { EmbossedIcon, type EmbossedIconKind } from './EmbossedIcon'

const SECTION_TOTAL = '003'
const rise = 'draft-motion animate-[draft-rise_0.9s_cubic-bezier(.2,.7,.2,1)_both]'

function SlideCounter({ index }: { index: number }) {
  return (
    <p className="text-[10px] tracking-[0.04em] text-[#262626]">
      {`00${index} / ${SECTION_TOTAL}`}
    </p>
  )
}

function DotPair() {
  return (
    <span aria-hidden="true" className="flex gap-1">
      <span className="size-1 rounded-full bg-[#1a1a1a]" />
      <span className="size-1 rounded-full bg-[#1a1a1a]" />
    </span>
  )
}

export function PrimaryPill({ children, onClick, type = 'button' }: {
  children: React.ReactNode
  onClick?: () => void
  type?: 'button' | 'submit'
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className="h-10 rounded-full bg-[#0d0d0d] px-8 text-[10.5px] font-medium uppercase tracking-[0.06em] text-white shadow-[0_0_0_1.5px_rgba(255,170,90,0.7),0_0_22px_rgba(255,150,60,0.55)] transition-all hover:shadow-[0_0_0_1.5px_rgba(255,180,100,0.9),0_0_32px_rgba(255,150,60,0.8)] active:scale-[0.98]"
    >
      {children}
    </button>
  )
}

function OutlinePill({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="h-10 rounded-full border border-black/35 px-8 text-[10.5px] font-medium uppercase tracking-[0.06em] text-[#1a1a1a] transition-colors hover:border-black/60 hover:bg-black/[0.04]"
    >
      {children}
    </button>
  )
}

type HeroProps = { onGetStarted: () => void; onExplore: () => void }

export function DraftHeroSection({ onGetStarted, onExplore }: HeroProps) {
  return (
    <section aria-labelledby="draft-hero-title" className="relative flex h-full snap-start flex-col">
      <div className="bg-[#c8c8c8] px-5 pb-6 pt-24 sm:px-8 md:pt-[104px]">
        <div className="flex flex-col gap-5 md:flex-row md:items-start">
          <h1
            id="draft-hero-title"
            className={`font-display text-[28px] font-medium uppercase leading-[1.12] text-[#141414] sm:text-[34px] md:w-[34%] ${rise}`}
          >
            Igniting deep
            <br />
            work with AI
          </h1>
          <div className="md:w-[42%]">
            <p className={`max-w-[310px] text-[14px] leading-[1.5] text-[#3a3a3a] ${rise}`} style={{ animationDelay: '120ms' }}>
              We build focus rooms and attribution intelligence for developers and students who ship.
            </p>
            <div className={`mt-6 flex flex-wrap gap-4 ${rise}`} style={{ animationDelay: '240ms' }}>
              <PrimaryPill onClick={onGetStarted}>Get started</PrimaryPill>
              <OutlinePill onClick={onExplore}>Our features</OutlinePill>
            </div>
          </div>
          <span className="ml-auto mt-3 hidden md:block">
            <DotPair />
          </span>
        </div>
        <div className="mt-5">
          <SlideCounter index={1} />
        </div>
      </div>
      <div className="relative flex-1">
        <p className="absolute bottom-16 left-5 hidden max-w-[230px] text-[12px] leading-[1.6] text-white [text-shadow:0_1px_8px_rgba(0,0,0,0.25)] sm:left-8 sm:block">
          Helping forward-looking builders thrive with shared focus sessions and live progress.
        </p>
      </div>
    </section>
  )
}

export function DraftAboutSection({ visible }: { visible: boolean }) {
  const reveal = visible ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
  return (
    <section aria-labelledby="draft-about-title" className="relative flex h-full snap-start flex-col px-5 pt-24 sm:px-8 md:pt-[104px]">
      <SlideCounter index={2} />
      <div className="flex flex-1 items-center pb-10">
        <div>
          <h2
            id="draft-about-title"
            className={`draft-motion font-display text-[26px] font-medium uppercase leading-[1.15] text-white transition-all duration-700 [text-shadow:0_2px_14px_rgba(0,0,0,0.25)] sm:text-[32px] ${reveal}`}
          >
            {"We're a full-stack"}
            <br />
            deep work campfire.
          </h2>
          <p
            className={`draft-motion mt-5 max-w-[240px] text-[12px] leading-[1.6] text-white/95 transition-all delay-150 duration-700 [text-shadow:0_1px_8px_rgba(0,0,0,0.25)] ${reveal}`}
          >
            Focus rooms, streaks and attribution insights, all under one roof.
          </p>
        </div>
      </div>
    </section>
  )
}

const FEATURES: { kind: EmbossedIconKind; title: string; body: string }[] = [
  {
    kind: 'ring',
    title: 'Focus Sessions',
    body: 'Timed deep-work rounds with ambient accountability. Stay in flow while the campfire keeps watch.',
  },
  {
    kind: 'triangle',
    title: 'Live Rooms',
    body: 'Join developers and students working in real time. Share progress without breaking concentration.',
  },
  {
    kind: 'diamond',
    title: 'Attribution Intelligence',
    body: 'See which habits, rooms and hours actually move your work forward, measured with precision.',
  },
]

export function DraftFeaturesSection({ visible }: { visible: boolean }) {
  return (
    <section aria-labelledby="draft-features-title" className="relative flex min-h-full snap-start flex-col bg-[#c8c8c8] px-5 pb-16 pt-24 sm:px-8 md:pt-[104px]">
      <SlideCounter index={3} />
      <div className="mt-5 flex flex-col gap-3 md:flex-row md:items-start">
        <h2 id="draft-features-title" className="font-display text-[24px] font-medium uppercase leading-[1.15] text-[#141414] sm:text-[28px] md:w-[34%]">
          Discover
          <br />
          our features
        </h2>
        <p className="max-w-[200px] text-[12px] leading-[1.6] text-[#3a3a3a]">
          Everything you need to do your best work, together.
        </p>
        <span className="ml-auto mt-2 hidden md:block">
          <DotPair />
        </span>
      </div>
      <ul className="mt-6 grid gap-4 md:grid-cols-3">
        {FEATURES.map((feature, index) => (
          <li
            key={feature.title}
            className={`draft-motion group flex flex-col rounded-[20px] border border-black/25 p-5 transition-all duration-1000 ease-out hover:-translate-y-1 hover:border-black/40 ${
              visible ? 'translate-y-0 opacity-100' : 'translate-y-24 opacity-0'
            }`}
            style={{ transitionDelay: visible ? `${index * 140}ms` : '0ms' }}
          >
            <div className="flex h-24 items-center justify-center sm:h-28">
              <EmbossedIcon kind={feature.kind} lit={visible} />
            </div>
            <h3 className="mt-4 text-[15px] font-medium text-[#1a1a1a]">{feature.title}</h3>
            <p className="mt-2 text-[11.5px] leading-[1.6] text-[#555]">{feature.body}</p>
          </li>
        ))}
      </ul>
    </section>
  )
}
