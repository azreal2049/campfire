type NavItem = { label: string; section?: number; showIndicator?: boolean }

const PRIMARY_NAV: NavItem[] = [
  { label: 'Home', section: 0, showIndicator: true },
  { label: 'About', section: 1, showIndicator: true },
  { label: 'Features', section: 2, showIndicator: true },
  { label: 'Plans' },
]

type DraftHeaderProps = {
  activeSection: number
  onNavigate: (section: number) => void
  onSignIn: () => void
}

function NavButton({
  item,
  active,
  onClick,
}: {
  item: NavItem
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-current={active ? 'true' : undefined}
      className="relative text-[10.5px] uppercase tracking-[0.06em] text-[#1c1c1c] transition-opacity hover:opacity-60"
    >
      {item.label}
      <span
        aria-hidden="true"
        className={`draft-motion absolute -bottom-[19px] left-1/2 h-[3px] w-14 -translate-x-1/2 rounded-full bg-[#ffad5c] shadow-[0_0_12px_3px_rgba(255,160,70,0.75)] transition-all duration-500 ${
          active ? 'scale-x-100 opacity-100' : 'scale-x-0 opacity-0'
        }`}
      />
    </button>
  )
}

export function DraftHeader({ activeSection, onNavigate, onSignIn }: DraftHeaderProps) {
  return (
    <header className="absolute inset-x-0 top-0 z-30 px-5 pt-4 sm:px-8 sm:pt-5">
      <div className="flex items-center justify-between border-b border-black/25 pb-4">
        <button
          type="button"
          onClick={() => onNavigate(0)}
          className="font-display text-[14px] font-medium uppercase tracking-[0.02em] text-[#141414]"
        >
          Campfire
        </button>

        <nav aria-label="Primary" className="hidden items-center gap-14 md:flex lg:gap-20">
          {PRIMARY_NAV.map((item) => (
            <NavButton
              key={item.label}
              item={item}
              active={Boolean(item.showIndicator) && item.section === activeSection}
              onClick={() => (item.section === undefined ? onSignIn() : onNavigate(item.section))}
            />
          ))}
        </nav>

        <div className="flex items-center gap-10">
          <span className="hidden md:inline">
            <NavButton item={{ label: 'Team' }} active={false} onClick={() => onNavigate(1)} />
          </span>
          <NavButton item={{ label: 'Sign in' }} active={false} onClick={onSignIn} />
        </div>
      </div>
    </header>
  )
}
