'use client'

import { Code, GraduationCap, X } from 'lucide-react'
import { useEffect, useRef, useState, type FormEvent } from 'react'
import { useCampfireStore, type CampfireRole } from '@/src/store/useCampfireStore'
import { PrimaryPill } from './DraftSections'

const ROLES: { value: CampfireRole; label: string; Icon: typeof Code }[] = [
  { value: 'developer', label: 'Developer', Icon: Code },
  { value: 'student', label: 'Student', Icon: GraduationCap },
]

const HANDLE_PATTERN = /^[a-z0-9_]{2,20}$/

type DraftSignInCardProps = { onClose: () => void }

export function DraftSignInCard({ onClose }: DraftSignInCardProps) {
  const signIn = useCampfireStore((state) => state.signIn)
  const [displayName, setDisplayName] = useState('')
  const [handle, setHandle] = useState('')
  const [role, setRole] = useState<CampfireRole>('developer')
  const [error, setError] = useState<string | null>(null)
  const nameRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    nameRef.current?.focus()
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const name = displayName.trim()
    const cleanHandle = handle.trim().replace(/^@/, '').toLowerCase()
    if (name.length < 2 || name.length > 40) {
      setError('Display name must be 2 to 40 characters.')
      return
    }
    if (!HANDLE_PATTERN.test(cleanHandle)) {
      setError('Handle must be 2 to 20 lowercase letters, numbers or underscores.')
      return
    }
    signIn({ displayName: name, handle: cleanHandle, role })
  }

  const fieldClass =
    'mt-1.5 h-10 w-full border-b border-black/30 bg-transparent text-[14px] text-[#141414] outline-none transition-colors placeholder:text-[#777] focus:border-[#ff9a3c]'

  return (
    <div
      className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-[#b9b9b9]/55 p-4 backdrop-blur-md"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose()
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="draft-signin-title"
        className="draft-motion relative my-auto w-full max-w-[380px] animate-[draft-rise_0.5s_cubic-bezier(.2,.7,.2,1)_both] rounded-[26px] border border-black/15 bg-[#cdcdcd]/95 p-6 shadow-[14px_18px_40px_rgba(0,0,0,0.22),-8px_-8px_24px_rgba(255,255,255,0.55)]"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close sign in"
          className="absolute right-4 top-4 flex size-8 items-center justify-center rounded-full text-[#333] transition-colors hover:bg-black/5"
        >
          <X className="size-4" aria-hidden="true" />
        </button>

        <p className="text-[10px] uppercase tracking-[0.08em] text-[#555]">Sign in</p>
        <h2 id="draft-signin-title" className="mt-2 font-display text-[22px] font-medium uppercase leading-[1.15] text-[#141414]">
          Ignite your
          <br />
          session
        </h2>

        <form onSubmit={handleSubmit} noValidate className="mt-5 flex flex-col gap-4">
          <label className="block text-[10.5px] uppercase tracking-[0.06em] text-[#444]">
            Display Name
            <input
              ref={nameRef}
              value={displayName}
              onChange={(event) => setDisplayName(event.target.value)}
              maxLength={40}
              autoComplete="name"
              placeholder="Ada Lovelace"
              className={fieldClass}
            />
          </label>
          <label className="block text-[10.5px] uppercase tracking-[0.06em] text-[#444]">
            @username Handle
            <input
              value={handle}
              onChange={(event) => setHandle(event.target.value)}
              maxLength={21}
              autoComplete="username"
              autoCapitalize="none"
              spellCheck={false}
              placeholder="@ada_codes"
              className={fieldClass}
            />
          </label>

          <div role="radiogroup" aria-label="Role" className="flex gap-2.5">
            {ROLES.map(({ value, label, Icon }) => {
              const selected = role === value
              return (
                <button
                  key={value}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => setRole(value)}
                  className={`flex h-9 flex-1 items-center justify-center gap-2 rounded-full border text-[12px] transition-all ${
                    selected
                      ? 'border-[#ff9a3c] bg-[#141414] text-white shadow-[0_0_16px_rgba(255,150,60,0.45)]'
                      : 'border-black/30 text-[#222] hover:border-black/50'
                  }`}
                >
                  <Icon className="size-3.5" aria-hidden="true" />
                  {label}
                </button>
              )
            })}
          </div>

          {error ? (
            <p role="alert" className="text-[12px] text-[#9a3412]">
              {error}
            </p>
          ) : null}

          <div className="mt-1">
            <PrimaryPill type="submit">{'Ignite session →'}</PrimaryPill>
          </div>
        </form>
      </div>
    </div>
  )
}
