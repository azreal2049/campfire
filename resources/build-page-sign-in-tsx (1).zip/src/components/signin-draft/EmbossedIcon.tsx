import { useId } from 'react'

export type EmbossedIconKind = 'ring' | 'triangle' | 'diamond'

const SHAPES: Record<EmbossedIconKind, string[]> = {
  ring: ['M 79 27.1 A 38 38 0 1 1 41 27.1', 'M 56.2 81.7 A 22 22 0 0 1 56.2 38.3'],
  triangle: ['M 60 16 L 104 96 L 16 96 Z', 'M 60 48 L 80 84 L 40 84 Z'],
  diamond: ['M 60 14 L 106 60 L 60 106 L 14 60 Z', 'M 60 38 L 82 60 L 60 82 L 38 60 Z'],
}

type EmbossedIconProps = {
  kind: EmbossedIconKind
  lit: boolean
}

export function EmbossedIcon({ kind, lit }: EmbossedIconProps) {
  const rawId = useId().replace(/[^a-zA-Z0-9_-]/g, '')
  const embossId = `emboss-${rawId}`
  const glowId = `glow-${rawId}`
  const paths = SHAPES[kind]

  return (
    <svg viewBox="0 0 120 120" aria-hidden="true" className="h-full w-auto overflow-visible">
      <defs>
        <filter id={embossId} x="-40%" y="-40%" width="180%" height="180%">
          <feDropShadow dx="6" dy="8" stdDeviation="5" floodColor="#000" floodOpacity="0.26" />
          <feDropShadow dx="-3" dy="-3" stdDeviation="2.5" floodColor="#fff" floodOpacity="0.85" />
        </filter>
        <filter id={glowId} x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="2.4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g
        filter={`url(#${embossId})`}
        fill="none"
        stroke="#d2d2d2"
        strokeWidth={8}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {paths.map((d) => (
          <path key={d} d={d} />
        ))}
      </g>
      <g
        filter={`url(#${glowId})`}
        fill="none"
        stroke="#ffad5c"
        strokeWidth={1.6}
        strokeLinecap="round"
        strokeLinejoin="round"
        transform="translate(1.5 -1.5)"
      >
        {paths.map((d, index) => (
          <path
            key={d}
            d={d}
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={lit ? 0 : 1}
            className="draft-motion"
            style={{ transition: `stroke-dashoffset 1.6s cubic-bezier(.4,0,.2,1) ${0.3 + index * 0.25}s` }}
          />
        ))}
      </g>
    </svg>
  )
}
