'use client'

import { useEffect, useRef, type RefObject } from 'react'

export type OrbPointer = { px: number; py: number; nx: number; ny: number; active: boolean }

type EmberOrbCanvasProps = {
  progressRef: RefObject<number>
  pointerRef: RefObject<OrbPointer>
}

type Vertex = { x: number; y: number; z: number; seed: number }
type Ember = { x: number; y: number; z: number; seed: number }

const VERTEX_COUNT = 340
const EMBER_COUNT = 80
const NEIGHBORS = 3

function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function buildMesh() {
  const rand = mulberry32(7)
  const golden = Math.PI * (3 - Math.sqrt(5))
  const vertices: Vertex[] = []

  for (let i = 0; i < VERTEX_COUNT; i++) {
    const y = 1 - (i / (VERTEX_COUNT - 1)) * 2
    const ring = Math.sqrt(1 - y * y)
    const theta = golden * i
    const jitter = 0.8 + rand() * 0.32
    vertices.push({
      x: Math.cos(theta) * ring * jitter + (rand() - 0.5) * 0.06,
      y: y * jitter + (rand() - 0.5) * 0.06,
      z: Math.sin(theta) * ring * jitter + (rand() - 0.5) * 0.06,
      seed: rand() * Math.PI * 2,
    })
  }

  const edgeKeys = new Set<number>()
  const edges: number[] = []
  for (let i = 0; i < VERTEX_COUNT; i++) {
    const a = vertices[i]
    const nearest: { j: number; d: number }[] = []
    for (let j = 0; j < VERTEX_COUNT; j++) {
      if (j === i) continue
      const b = vertices[j]
      const d = (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2
      nearest.push({ j, d })
    }
    nearest.sort((m, n) => m.d - n.d)
    for (let k = 0; k < NEIGHBORS; k++) {
      const j = nearest[k].j
      const key = i < j ? i * VERTEX_COUNT + j : j * VERTEX_COUNT + i
      if (!edgeKeys.has(key)) {
        edgeKeys.add(key)
        edges.push(i, j)
      }
    }
  }

  const embers: Ember[] = []
  for (let i = 0; i < EMBER_COUNT; i++) {
    const r = 0.15 + rand() * 0.7
    const u = rand() * Math.PI * 2
    const v = Math.acos(2 * rand() - 1)
    embers.push({
      x: r * Math.sin(v) * Math.cos(u),
      y: r * Math.cos(v),
      z: r * Math.sin(v) * Math.sin(u),
      seed: rand() * Math.PI * 2,
    })
  }

  return { vertices, edges: Uint16Array.from(edges), embers }
}

const clamp01 = (v: number) => Math.min(1, Math.max(0, v))
const lerp = (a: number, b: number, t: number) => a + (b - a) * t
const easeOutCubic = (t: number) => 1 - (1 - t) ** 3
const easeInOut = (t: number) => (t < 0.5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2)

export function EmberOrbCanvas({ progressRef, pointerRef }: EmberOrbCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return

    const { vertices, edges, embers } = buildMesh()
    const sx = new Float32Array(VERTEX_COUNT)
    const sy = new Float32Array(VERTEX_COUNT)
    const sz = new Float32Array(VERTEX_COUNT)
    const heat = new Float32Array(VERTEX_COUNT)
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches

    let width = 0
    let height = 0
    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      width = rect.width
      height = rect.height
      canvas.width = Math.round(width * dpr)
      canvas.height = Math.round(height * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    const observer = new ResizeObserver(resize)
    observer.observe(canvas)

    const tilt = { x: 0, y: 0 }
    const hot = { x: 0.45, y: 0.55, z: -0.7 }
    let start = 0
    let raf = 0

    const render = (now: number) => {
      raf = requestAnimationFrame(render)
      if (!start) start = now
      const t = now - start
      const progress = progressRef.current ?? 0
      ctx.clearRect(0, 0, width, height)
      if (progress > 1.98 || width === 0) return

      const entrance = reduceMotion ? 1 : easeOutCubic(clamp01(t / 1800))
      const pointer = pointerRef.current

      tilt.x += ((pointer?.active ? pointer.nx : 0) - tilt.x) * 0.04
      tilt.y += ((pointer?.active ? pointer.ny : 0) - tilt.y) * 0.04

      const minDim = Math.min(width, height)
      const cx = width / 2
      const cy =
        progress <= 1
          ? lerp(height * 0.86, height * 0.5, easeInOut(clamp01(progress)))
          : height * 0.5 - (progress - 1) * height
      const radius = minDim * lerp(0.34, 0.3, clamp01(progress)) * (0.92 + 0.08 * entrance)

      const spin = reduceMotion ? 0.00005 : 0.00016
      const rotY = t * spin + tilt.x * 0.6 + (1 - entrance) * 2.4
      const rotX = -0.25 + tilt.y * 0.35
      const cosY = Math.cos(rotY)
      const sinY = Math.sin(rotY)
      const cosX = Math.cos(rotX)
      const sinX = Math.sin(rotX)

      let targetX = 0.55 * Math.cos(t * 0.00035) + 0.15
      let targetY = 0.45 + 0.3 * Math.sin(t * 0.00027)
      let targetZ = -0.75
      if (pointer?.active) {
        targetX = (pointer.px - cx) / radius
        targetY = (pointer.py - cy) / radius
        targetZ = -0.55
      }
      const targetLen = Math.hypot(targetX, targetY, targetZ) || 1
      hot.x += (targetX / targetLen - hot.x) * 0.06
      hot.y += (targetY / targetLen - hot.y) * 0.06
      hot.z += (targetZ / targetLen - hot.z) * 0.06
      const hotLen = Math.hypot(hot.x, hot.y, hot.z) || 1
      const hx = hot.x / hotLen
      const hy = hot.y / hotLen
      const hz = hot.z / hotLen

      const spread = lerp(2.8, 1, entrance)
      for (let i = 0; i < VERTEX_COUNT; i++) {
        const v = vertices[i]
        const wobble = (1 + 0.045 * Math.sin(t * 0.0012 + v.seed * 3)) * spread
        const x0 = v.x * wobble
        const y0 = v.y * wobble
        const z0 = v.z * wobble
        const x1 = x0 * cosY + z0 * sinY
        const z1 = -x0 * sinY + z0 * cosY
        const y2 = y0 * cosX - z1 * sinX
        const z2 = y0 * sinX + z1 * cosX
        const persp = 3 / (3 + z2)
        sx[i] = cx + x1 * radius * persp
        sy[i] = cy + y2 * radius * persp
        sz[i] = z2
        const len = Math.hypot(x1, y2, z2) || 1
        const facing = Math.max(0, (x1 * hx + y2 * hy + z2 * hz) / len)
        heat[i] = facing ** 5 * (0.75 + 0.25 * Math.sin(t * 0.003 + v.seed)) * entrance
      }

      ctx.globalCompositeOperation = 'source-over'
      ctx.lineWidth = 1
      ctx.strokeStyle = 'rgba(20, 20, 22, 0.22)'
      ctx.beginPath()
      ctx.arc(cx, cy, radius * 1.32, 0, Math.PI * 2)
      ctx.stroke()
      ctx.strokeStyle = 'rgba(20, 20, 22, 0.14)'
      ctx.beginPath()
      ctx.arc(cx, cy, radius * 1.58, 0, Math.PI * 2)
      ctx.stroke()
      ctx.lineWidth = 28
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.09)'
      ctx.beginPath()
      ctx.arc(cx, cy, radius * 1.45, 0, Math.PI * 2)
      ctx.stroke()

      const smoke = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius * 0.95)
      smoke.addColorStop(0, 'rgba(60, 54, 50, 0.32)')
      smoke.addColorStop(1, 'rgba(60, 54, 50, 0)')
      ctx.fillStyle = smoke
      ctx.beginPath()
      ctx.arc(cx, cy, radius * 0.95, 0, Math.PI * 2)
      ctx.fill()

      const buckets = [
        { max: -0.3, alpha: 0.6 },
        { max: 0.35, alpha: 0.36 },
        { max: Infinity, alpha: 0.16 },
      ]
      ctx.lineWidth = 0.75
      for (const bucket of [...buckets].reverse()) {
        ctx.strokeStyle = `rgba(22, 22, 24, ${bucket.alpha * entrance})`
        ctx.beginPath()
        for (let e = 0; e < edges.length; e += 2) {
          const a = edges[e]
          const b = edges[e + 1]
          const depth = (sz[a] + sz[b]) / 2
          const index = depth < buckets[0].max ? 0 : depth < buckets[1].max ? 1 : 2
          if (buckets[index] !== bucket) continue
          ctx.moveTo(sx[a], sy[a])
          ctx.lineTo(sx[b], sy[b])
        }
        ctx.stroke()
      }

      ctx.fillStyle = `rgba(18, 18, 20, ${0.55 * entrance})`
      ctx.beginPath()
      for (let i = 0; i < VERTEX_COUNT; i++) {
        const size = 1.1 * (3 / (3 + sz[i]))
        ctx.rect(sx[i] - size / 2, sy[i] - size / 2, size, size)
      }
      ctx.fill()

      ctx.globalCompositeOperation = 'lighter'
      for (let e = 0; e < edges.length; e += 2) {
        const a = edges[e]
        const b = edges[e + 1]
        const h = (heat[a] + heat[b]) / 2
        if (h < 0.04) continue
        ctx.strokeStyle = `rgba(255, 150, 70, ${Math.min(1, h * 1.2)})`
        ctx.lineWidth = 1 + h * 1.6
        ctx.beginPath()
        ctx.moveTo(sx[a], sy[a])
        ctx.lineTo(sx[b], sy[b])
        ctx.stroke()
      }
      for (let i = 0; i < VERTEX_COUNT; i++) {
        const h = heat[i]
        if (h < 0.06) continue
        ctx.fillStyle = `rgba(255, 190, 120, ${Math.min(1, h * 1.4)})`
        ctx.beginPath()
        ctx.arc(sx[i], sy[i], 1.2 + h * 3, 0, Math.PI * 2)
        ctx.fill()
      }

      for (const ember of embers) {
        const x1 = ember.x * cosY + ember.z * sinY
        const z1 = -ember.x * sinY + ember.z * cosY
        const drift = Math.sin(t * 0.0009 + ember.seed) * 0.05
        const y2 = (ember.y + drift) * cosX - z1 * sinX
        const z2 = (ember.y + drift) * sinX + z1 * cosX
        const persp = 3 / (3 + z2)
        const twinkle = 0.35 + 0.65 * Math.abs(Math.sin(t * 0.002 + ember.seed * 5))
        ctx.fillStyle = `rgba(255, 120, 50, ${0.7 * twinkle * entrance})`
        ctx.beginPath()
        ctx.arc(cx + x1 * radius * persp, cy + y2 * radius * persp, 1.4 * persp, 0, Math.PI * 2)
        ctx.fill()
      }

      const pulse = 0.85 + 0.15 * Math.sin(t * 0.0021)
      const gx = cx + hx * radius * 0.32
      const gy = cy + hy * radius * 0.32
      const core = ctx.createRadialGradient(gx, gy, 0, gx, gy, radius * 0.6)
      core.addColorStop(0, `rgba(255, 245, 225, ${0.95 * pulse * entrance})`)
      core.addColorStop(0.18, `rgba(255, 175, 90, ${0.6 * pulse * entrance})`)
      core.addColorStop(0.55, `rgba(255, 120, 40, ${0.14 * entrance})`)
      core.addColorStop(1, 'rgba(255, 120, 40, 0)')
      ctx.fillStyle = core
      ctx.beginPath()
      ctx.arc(gx, gy, radius * 0.6, 0, Math.PI * 2)
      ctx.fill()
      ctx.globalCompositeOperation = 'source-over'
    }

    raf = requestAnimationFrame(render)
    return () => {
      cancelAnimationFrame(raf)
      observer.disconnect()
    }
  }, [progressRef, pointerRef])

  return <canvas ref={canvasRef} aria-hidden="true" className="pointer-events-none absolute inset-0 z-0 h-full w-full" />
}
