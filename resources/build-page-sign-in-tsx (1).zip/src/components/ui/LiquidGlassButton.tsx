'use client'

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type CSSProperties,
  type MouseEvent,
  type PointerEvent,
  type ReactNode,
} from 'react'
import { cn } from '@/lib/utils'

export type LiquidGlassVariant = 'pearl' | 'obsidian' | 'pill'

type Ripple = { id: number; x: number; y: number; size: number }

type LiquidGlassButtonProps = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'> & {
  variant?: LiquidGlassVariant
  trailingIcon?: ReactNode
  /** Delay (ms) before onClick fires so the ripple burst is visible before the UI transitions. */
  actionDelay?: number
  onClick?: (event: MouseEvent<HTMLButtonElement>) => void
}

const BASE =
  'group relative isolate inline-flex cursor-pointer select-none items-center justify-center gap-2 overflow-hidden rounded-full outline-none transform-gpu will-change-transform transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] active:duration-75 focus-visible:ring-2 focus-visible:ring-sky-400/70 focus-visible:ring-offset-2 focus-visible:ring-offset-black disabled:pointer-events-none disabled:opacity-60'

const VARIANTS: Record<LiquidGlassVariant, string> = {
  pearl:
    'border border-white/90 bg-gradient-to-b from-white/[0.92] via-white/[0.82] to-zinc-200/[0.78] font-semibold text-[#070709] backdrop-blur-2xl shadow-[0_10px_35px_-5px_rgba(255,255,255,0.35),0_2px_10px_rgba(0,0,0,0.5),inset_0_1.5px_1px_rgba(255,255,255,1),inset_0_-2px_4px_rgba(0,0,0,0.18)] hover:-translate-y-[2px] hover:scale-[1.03] hover:shadow-[0_14px_45px_-4px_rgba(255,255,255,0.55),0_0_25px_rgba(56,189,248,0.25),inset_0_1.5px_2px_rgba(255,255,255,1)] active:translate-y-[1px] active:scale-[0.96] active:shadow-[0_4px_15px_rgba(255,255,255,0.2),inset_0_2px_6px_rgba(0,0,0,0.28)]',
  obsidian:
    'border border-white/[0.16] bg-gradient-to-b from-white/[0.12] via-white/[0.05] to-black/[0.45] font-medium text-white backdrop-blur-2xl backdrop-saturate-[180%] shadow-[0_12px_32px_-4px_rgba(0,0,0,0.75),inset_0_1px_0_0_rgba(255,255,255,0.32),inset_0_-1px_0_0_rgba(255,255,255,0.06)] hover:-translate-y-[2px] hover:scale-[1.03] hover:border-white/[0.32] hover:shadow-[0_16px_40px_-4px_rgba(0,0,0,0.85),0_0_25px_-2px_rgba(56,189,248,0.22),inset_0_1px_1px_0_rgba(255,255,255,0.5)] active:translate-y-[1px] active:scale-[0.96] active:bg-white/[0.04] active:shadow-[inset_0_3px_8px_rgba(0,0,0,0.7)]',
  pill: 'px-4 py-1.5 text-[13.5px] text-zinc-400 hover:scale-[1.02] hover:text-white active:scale-[0.95] active:bg-white/[0.06]',
}

const GLOW: Record<LiquidGlassVariant, string> = {
  pearl:
    'radial-gradient(110px circle at var(--mouse-x) var(--mouse-y), rgba(255,255,255,0.85), rgba(56,189,248,0.14) 45%, transparent 80%)',
  obsidian:
    'radial-gradient(120px circle at var(--mouse-x) var(--mouse-y), rgba(255,255,255,0.22), rgba(56,189,248,0.08) 45%, transparent 80%)',
  pill: 'radial-gradient(80px circle at var(--mouse-x) var(--mouse-y), rgba(255,255,255,0.14), transparent 75%)',
}

const RIM_STYLE: CSSProperties = {
  padding: 1,
  background:
    'radial-gradient(70px circle at var(--mouse-x) var(--mouse-y), rgba(255,255,255,0.95), rgba(125,211,252,0.45) 40%, transparent 75%)',
  WebkitMask: 'linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)',
  WebkitMaskComposite: 'xor',
  mask: 'linear-gradient(#000 0 0) content-box exclude, linear-gradient(#000 0 0)',
}

const INITIAL_VARS = { '--mouse-x': '50%', '--mouse-y': '50%' } as CSSProperties

export function LiquidGlassButton({
  variant = 'obsidian',
  trailingIcon,
  actionDelay = 0,
  className,
  style,
  children,
  onClick,
  onMouseMove,
  onPointerDown,
  ...rest
}: LiquidGlassButtonProps) {
  const ref = useRef<HTMLButtonElement>(null)
  const [ripples, setRipples] = useState<Ripple[]>([])
  const timers = useRef<number[]>([])

  useEffect(() => {
    const pending = timers.current
    return () => pending.forEach((id) => window.clearTimeout(id))
  }, [])

  const schedule = useCallback((fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms))
  }, [])

  const handleMouseMove = (event: MouseEvent<HTMLButtonElement>) => {
    const node = ref.current
    if (node) {
      const rect = node.getBoundingClientRect()
      node.style.setProperty('--mouse-x', `${event.clientX - rect.left}px`)
      node.style.setProperty('--mouse-y', `${event.clientY - rect.top}px`)
    }
    onMouseMove?.(event)
  }

  const handlePointerDown = (event: PointerEvent<HTMLButtonElement>) => {
    const node = ref.current
    if (node) {
      const rect = node.getBoundingClientRect()
      const size = Math.max(rect.width, rect.height) * 1.1
      const ripple = { id: event.timeStamp, x: event.clientX - rect.left, y: event.clientY - rect.top, size }
      setRipples((current) => [...current, ripple])
      schedule(() => setRipples((current) => current.filter((r) => r.id !== ripple.id)), 650)
    }
    onPointerDown?.(event)
  }

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    if (!onClick) return
    if (actionDelay > 0) schedule(() => onClick(event), actionDelay)
    else onClick(event)
  }

  const rippleColor = variant === 'pearl' ? 'bg-sky-400/35' : 'bg-white/30'

  return (
    <button
      ref={ref}
      {...rest}
      style={{ ...INITIAL_VARS, ...style }}
      onMouseMove={handleMouseMove}
      onPointerDown={handlePointerDown}
      onClick={handleClick}
      className={cn(BASE, VARIANTS[variant], className)}
    >
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 rounded-[inherit] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{ background: GLOW[variant] }}
      />
      {variant !== 'pill' ? (
        <>
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 rounded-[inherit] opacity-0 transition-opacity duration-300 group-hover:opacity-100"
            style={RIM_STYLE}
          />
          <span
            aria-hidden="true"
            className={cn(
              'pointer-events-none absolute inset-y-0 left-0 -z-10 w-full -translate-x-full skew-x-[-20deg] bg-gradient-to-r from-transparent to-transparent transition-transform duration-700 ease-out group-hover:translate-x-full',
              variant === 'pearl' ? 'via-white/70' : 'via-white/[0.14]',
            )}
          />
        </>
      ) : null}
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          aria-hidden="true"
          className={cn('pointer-events-none absolute -z-10 animate-ping rounded-full', rippleColor)}
          style={{
            left: ripple.x - ripple.size / 2,
            top: ripple.y - ripple.size / 2,
            width: ripple.size,
            height: ripple.size,
            animationDuration: '650ms',
          }}
        />
      ))}
      <span className="relative z-10 inline-flex items-center gap-[inherit]">{children}</span>
      {trailingIcon ? (
        <span
          aria-hidden="true"
          className="relative z-10 inline-flex transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:translate-x-1 group-active:translate-x-0.5"
        >
          {trailingIcon}
        </span>
      ) : null}
    </button>
  )
}
