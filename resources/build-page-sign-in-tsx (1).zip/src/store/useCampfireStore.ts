import { create } from 'zustand'

export type CampfirePage = 'page-signin' | 'page-lobby'
export type CampfireRole = 'developer' | 'student'

export type CampfireProfile = {
  displayName: string
  handle: string
  role: CampfireRole
}

export type SignInVariant = 'draft' | 'classic'

type CampfireState = {
  activePage: CampfirePage
  signInVariant: SignInVariant
  setSignInVariant: (variant: SignInVariant) => void
  displayName: string
  handle: string
  role: CampfireRole | null
  setActivePage: (page: CampfirePage) => void
  signIn: (profile: CampfireProfile) => void
  signOut: () => void
}

export const useCampfireStore = create<CampfireState>()((set) => ({
  activePage: 'page-signin',
  signInVariant: 'draft',
  setSignInVariant: (signInVariant) => set({ signInVariant }),
  displayName: '',
  handle: '',
  role: null,
  setActivePage: (activePage) => set({ activePage }),
  signIn: ({ displayName, handle, role }) =>
    set({ displayName, handle, role, activePage: 'page-lobby' }),
  signOut: () =>
    set({ displayName: '', handle: '', role: null, activePage: 'page-signin' }),
}))
