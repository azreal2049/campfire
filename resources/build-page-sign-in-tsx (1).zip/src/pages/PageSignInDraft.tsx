'use client'

import { useCallback, useRef, useState, type PointerEvent } from 'react'
import { DraftFooterBar } from '@/src/components/signin-draft/DraftFooterBar'
import { DraftHeader } from '@/src/components/signin-draft/DraftHeader'
import {
  DraftAboutSection,
  DraftFeaturesSection,
  DraftHeroSection,
} from '@/src/components/signin-draft/DraftSections'
import { DraftSignInCard } from '@/src/components/signin-draft/DraftSignInCard'
import { EmberOrbCanvas, type OrbPointer } from '@/src/components/signin-draft/EmberOrbCanvas'

const SECTION_COUNT = 3

export default function PageSignInDraft() {
  const frameRef = useRef<HTMLDivElement>(null)
  const scrollerRef = useRef<HTMLDivElement>(null)
  const progressRef = useRef(0)
  const pointerRef = useRef<OrbPointer>({ px: 0, py: 0, nx: 0, ny: 0, active: false })
  const [activeSection, setActiveSection] = useState(0)
  const [revealed, setRevealed] = useState(0)
  const [isSignInOpen, setIsSignInOpen] = useState(false)

  const openSignIn = useCallback(() => setIsSignInOpen(true), [])
  const closeSignIn = useCallback(() => setIsSignInOpen(false), [])

  const scrollToSection = useCallback((section: number) => {
    const scroller = scrollerRef.current
    const target = scroller?.children[section] as HTMLElement | undefined
    if (scroller && target) scroller.scrollTo({ top: target.offsetTop, behavior: 'smooth' })
  }, [])

  const handleScroll = () => {
    const scroller = scrollerRef.current
    if (!scroller) return
    const progress = scroller.scrollTop / Math.max(1, scroller.clientHeight)
    progressRef.current = progress
    const section = Math.min(SECTION_COUNT - 1, Math.round(progress))
    setActiveSection(section)
    setRevealed((current) => Math.max(current, Math.min(SECTION_COUNT - 1, Math.floor(progress + 0.45))))
  }

  const handlePointerMove = (event: PointerEvent<HTMLDivElement>) => {
    const rect = frameRef.current?.getBoundingClientRect()
    if (!rect) return
    const px = event.clientX - rect.left
    const py = event.clientY - rect.top
    pointerRef.current = {
      px,
      py,
      nx: (px / rect.width) * 2 - 1,
      ny: (py / rect.height) * 2 - 1,
      active: true,
    }
  }

  const handlePointerLeave = () => {
    pointerRef.current = { ...pointerRef.current, active: false }
  }

  return (
    <div
      data-page="page-signin"
      data-variant="draft"
      className="flex min-h-dvh items-center justify-center bg-[radial-gradient(ellipse_at_50%_105%,rgba(255,170,90,0.35)_0%,transparent_45%),linear-gradient(135deg,#9a9a9a_0%,#6e6e6e_55%,#4a4a4a_100%)] p-2.5 font-sans sm:p-5"
    >
      <div className="h-[calc(100dvh-20px)] w-full max-w-[1180px] rounded-[30px] border border-white/25 bg-white/15 p-2 shadow-[0_30px_80px_rgba(0,0,0,0.35)] sm:h-[calc(100dvh-40px)] sm:rounded-[36px] sm:p-2.5">
        <div
          ref={frameRef}
          onPointerMove={handlePointerMove}
          onPointerLeave={handlePointerLeave}
          className="relative h-full w-full overflow-hidden rounded-[22px] bg-[radial-gradient(ellipse_at_72%_28%,#e6e6e6_0%,#c6c6c6_45%,#a8a8a8_100%)] sm:rounded-[28px]"
        >
          <EmberOrbCanvas progressRef={progressRef} pointerRef={pointerRef} />
          <DraftHeader activeSection={activeSection} onNavigate={scrollToSection} onSignIn={openSignIn} />

          <main
            ref={scrollerRef}
            onScroll={handleScroll}
            className="draft-scroller absolute inset-0 z-10 snap-y snap-mandatory overflow-y-auto"
          >
            <DraftHeroSection onGetStarted={openSignIn} onExplore={() => scrollToSection(2)} />
            <DraftAboutSection visible={revealed >= 1} />
            <DraftFeaturesSection visible={revealed >= 2} />
          </main>

          <DraftFooterBar
            isLast={activeSection === SECTION_COUNT - 1}
            onNext={() => scrollToSection(activeSection === SECTION_COUNT - 1 ? 0 : activeSection + 1)}
          />

          {isSignInOpen ? <DraftSignInCard onClose={closeSignIn} /> : null}
        </div>
      </div>
    </div>
  )
}
