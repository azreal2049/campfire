'use client'

import { useCampfireStore } from '@/src/store/useCampfireStore'

export default function PageLobby() {
  const displayName = useCampfireStore((state) => state.displayName)
  const handle = useCampfireStore((state) => state.handle)
  const role = useCampfireStore((state) => state.role)
  const signOut = useCampfireStore((state) => state.signOut)

  return (
    <main
      data-page="page-lobby"
      className="flex min-h-screen flex-col items-center justify-center gap-4 bg-black px-6 text-center font-sans text-white"
    >
      <p className="text-[13px] uppercase tracking-[0.2em] text-sky-400">Lobby</p>
      <h1 className="text-balance text-4xl font-semibold tracking-[-0.03em]">Welcome, {displayName}</h1>
      <p className="text-[15px] text-zinc-400">
        @{handle} · {role === 'student' ? '🧬 Student' : '💻 Developer'}
      </p>
      <button
        type="button"
        onClick={signOut}
        className="mt-4 rounded-full border border-white/25 px-6 py-2.5 text-[13.5px] transition-all hover:border-white/50 hover:bg-white/[0.08]"
      >
        Sign out
      </button>
    </main>
  )
}
