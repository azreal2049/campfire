'use client'

import { useCallback, useState } from 'react'
import { GlassSignInCard } from '@/src/components/signin/GlassSignInCard'
import { ParticleHeadCanvas } from '@/src/components/signin/ParticleHeadCanvas'
import { SignInHeader } from '@/src/components/signin/SignInHeader'
import { SignInHero, type HeadlineVariant } from '@/src/components/signin/SignInHero'

type PageSignInProps = {
  initialHeadline?: HeadlineVariant
}

export default function PageSignIn({ initialHeadline = 'deep-work' }: PageSignInProps) {
  const [isSignInOpen, setIsSignInOpen] = useState(false)
  const [headline, setHeadline] = useState<HeadlineVariant>(initialHeadline)

  const openSignIn = useCallback(() => setIsSignInOpen(true), [])
  const closeSignIn = useCallback(() => setIsSignInOpen(false), [])
  const toggleHeadline = useCallback(
    () => setHeadline((current) => (current === 'deep-work' ? 'attribution' : 'deep-work')),
    [],
  )

  return (
    <div data-page="page-signin" className="relative min-h-screen overflow-hidden bg-black font-sans">
      <ParticleHeadCanvas />
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 z-[1] bg-[radial-gradient(ellipse_at_50%_42%,transparent_35%,rgba(0,0,0,0.55)_85%)]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-x-0 bottom-0 z-[1] h-40 bg-gradient-to-t from-black to-transparent"
      />

      <main className="pointer-events-none relative z-10 flex min-h-screen flex-col justify-between">
        <SignInHeader onGetStarted={openSignIn} />
        <SignInHero
          variant={headline}
          hidden={isSignInOpen}
          onToggleVariant={toggleHeadline}
          onOpenSignIn={openSignIn}
        />
      </main>

      {isSignInOpen ? <GlassSignInCard onClose={closeSignIn} /> : null}
    </div>
  )
}
