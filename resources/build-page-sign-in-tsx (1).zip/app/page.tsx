import { CampfireApp } from '@/src/components/CampfireApp'

export default function Page() {
  return <CampfireApp />
}
